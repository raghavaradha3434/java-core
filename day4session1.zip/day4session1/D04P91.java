package com.learning.core.day4session1;

public class D04P91 {
	private int maxSize;
    private String[] stackArray;
    private int top;

    public D04P91(int size) {
        this.maxSize = size;
        this.stackArray = new String[maxSize];
        this.top = -1;
    }

    public void push(String element) {
        if (top < maxSize - 1) {
            top++;
            stackArray[top] = element;
        } else {
            System.out.println("Stack is full. Cannot push element: " + element);
        }
    }

    public String pop() {
        if (top >= 0) {
            String poppedElement = stackArray[top];
            top--;
            return poppedElement;
        } else {
            System.out.println("Stack is empty.");
            return null;
        }
    }

    public static void main(String[] args) {
    	D04P91 stack = new D04P91(5);

        stack.push("hello");
        stack.push("world");
        stack.push("Java");
        stack.push("programming");

        System.out.println("After pushing 4 Elements: ");
        for (int i = 0; i <= stack.top; i++) {
        	//Pushing elements
            System.out.print(stack.stackArray[i] + " ");
        }
        System.out.println();

        System.out.println("After a popping: ");
        for (int i = 0; i < 3; i++) {
        	// Pop 3 elements
            System.out.print(stack.pop() + " ");
        }
        System.out.println();
    }
}


